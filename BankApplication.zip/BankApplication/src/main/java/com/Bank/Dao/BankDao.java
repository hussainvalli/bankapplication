package com.Bank.Dao;

import com.Bank.Dto.BankDto;

import java.util.List;
//BankDao is an interface. BankDaoImpl is the implementation class for this interface
public interface BankDao
{
    public int createAccountInDao(BankDto dt);

    public BankDto retriveCustomerDetails(String BankName);

    public int deleteCustomerFromBankDao(String address);

    public int amountAddDao(BankDto dto);

    public double receiveMoneyFromAccountDao(BankDto dto);
}
