package com.Bank.Dao;

import com.Bank.DataBaseConnection.MySqlConnector;
import com.Bank.Dto.BankDto;
import org.apache.log4j.Logger;

import java.sql.*;

public class BankDaoImpl implements BankDao
{
    /*This logging allows you to report and persist error and warning
   messages as well as info messages
   */
    static final Logger log=Logger.getLogger(BankDaoImpl.class);

   // from these class we are getting the connection from database
    MySqlConnector mc= new MySqlConnector();


    int  createStatus,creadingStatus,deleteStatus;

    //creating connection from the database
    Connection con=mc.getConnection();
    PreparedStatement pstmt;
    //this query for creating account for customer
    private static final String SQL_CREATE_DETAILS_INTO_DB="insert into Bank.tbl_Bank(name1,bankname,password1,address,emailid,Amount) values(?,?,?,?,?,?) ";

    //this query for retriving the customer details from the database
    private static final String SQL_RETRIVE_FROM_DB="select name1,bankname,address,emailid,Amount from Bank.tbl_Bank where password1=?";

    //this query for deleting the customer account from the database.
    private static final String SQL_DELETE_FROM_DB="delete from Bank.tbl_Bank where address=?";

    //this query for credit
    private static final String SQL_ADD_AMOUNT_TO_DB="update Bank.tbl_Bank set Amount=?+Amount where password1=?" ;

    //this query for debit
    private static final String SQL_SELECT_AMOUNT_FROM_DB="select Amount from Bank.tbl_Bank where name1=? and password1=?" ;
    private static final String SQL_RECEIVE_AMOUNT_FROM_DB="update Bank.tbl_Bank set Amount=Amount-? where name1=? and password1=?" ;



    //this method for creating the account for customer
    @Override
    public int createAccountInDao(BankDto dt)
    {
        //preparedstatement throws the SQLException. it handled by try and catch.
          try {

            //passing the query to preparedstatement
            pstmt=con.prepareStatement(SQL_CREATE_DETAILS_INTO_DB);

            //setting the values to the preparedStatement
                pstmt.setString(1,dt.getName());
                pstmt.setString(2,dt.getBankName());
                pstmt.setString(3,dt.getPassword());
                pstmt.setString(4,dt.getAddress());
                pstmt.setString(5,dt.getEmailId());
                pstmt.setDouble(6,dt.getAmount());

                //checking with log4j whether we are getting required data or not.
                log.info("in dao impl");
                log.info(dt.getName());
                log.info(dt.getBankName());
                log.info(dt.getPassword());
                log.info(dt.getAddress());
                log.info(dt.getEmailId());
                log.info(dt.getAmount());

                //execute the query. it will return int as as a result
                createStatus=pstmt.executeUpdate();
            }
               catch(Exception ex)
            {
                ex.printStackTrace();

            }

        return  createStatus;

    }






    //method to retriving the customer details from the database
    @Override
    public BankDto retriveCustomerDetails(String password)
    {

          BankDto dt=new BankDto();

        try {
            //passing the query to the preparedstatement
            pstmt=con.prepareStatement(SQL_RETRIVE_FROM_DB);

            //setting the value
            pstmt.setString(1,password);

            //execute query. it returns ResultSet object
           ResultSet rs= pstmt.executeQuery();

           //from Resultset object we need to get the required data
           while(rs.next())
           {

              //getting data from ResultsSet
               dt.setName(rs.getString(1));
               dt.setBankName(rs.getString(2));
               dt.setAddress(rs.getString(3));
               dt.setEmailId(rs.getString(4));
               dt.setAmount(rs.getDouble(5));
           }

        }catch (SQLException ea)
        {
            ea.printStackTrace();
        }



        return dt;
    }

     //method for deleteing the Customeraccount from the database by passing address as input
    @Override
    public int deleteCustomerFromBankDao(String address)
    {
        try {
            //passig the query to the preparedstatement
            pstmt=con.prepareStatement(SQL_DELETE_FROM_DB);

            //setting the value
            pstmt.setString(1,address);

            //execute the query.it returns the int value
           deleteStatus=pstmt.executeUpdate();

        } catch (SQLException e)
          {
            e.printStackTrace();
           }

        return deleteStatus;
    }
    //method to add the amount to the customer account by passing the  customerpassword
    @Override
    public int amountAddDao(BankDto dto)
    {
        String pass=dto.getPassword();
        double amt=dto.getAmount();

        try {
            //passig the query to the preparedstatement
            pstmt=con.prepareStatement(SQL_ADD_AMOUNT_TO_DB);

            //setting the values
            pstmt.setDouble(1,amt);
            pstmt.setString(2,pass);


            //execute the query.it returns the int value
            creadingStatus=pstmt.executeUpdate();
        } catch (SQLException e)
        {
            e.printStackTrace();
        }


        return creadingStatus;
    }
   //method to receive the amount from the customeraccount by passing name & password
    @Override
    public double receiveMoneyFromAccountDao(BankDto dto)
    {
        double deditStatus=0;
        String na=dto.getName();
        String pass=dto.getPassword();
        double amt=dto.getAmount();

        try {

            pstmt = con.prepareStatement(SQL_SELECT_AMOUNT_FROM_DB);
            pstmt.setString(1, na);
            pstmt.setString(2, pass);
            ResultSet rs=pstmt.executeQuery();
            rs.next();
            Double amountCheck=rs.getDouble(1);

            log.info(amountCheck+"select amount");

            if(amountCheck > amt){
                //passig the query to the preparedstatement
                pstmt = con.prepareStatement(SQL_RECEIVE_AMOUNT_FROM_DB);

                //setting the values
                pstmt.setDouble(1, amt);
                pstmt.setString(2, na);
                pstmt.setString(3, pass);

                //execute the query
                int debitCheck = pstmt.executeUpdate();

                log.info("in receive amoubt"+debitCheck);

                //if the above operation done successfully then only allowed to get the remaining balance
                if (debitCheck == 1) {

                    //this code is to get the remaining Balance in the customerAccount after receiving the money
                    try {
                        Statement s = con.createStatement();
                        //query for getting Amount in the customerAccount
                        String str = "select Amount from Bank.tbl_Bank where password1=" + pass;
                        ResultSet rs1 = s.executeQuery(str);
                        rs1.next();
                        //here we are receiving amount from the Resultset
                        deditStatus = rs1.getDouble(1);

                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

            }
            else
            {
                deditStatus=-1;
            }
        }catch(SQLException ea)
            {
                ea.printStackTrace();
            }


        return  deditStatus;
    }
}
