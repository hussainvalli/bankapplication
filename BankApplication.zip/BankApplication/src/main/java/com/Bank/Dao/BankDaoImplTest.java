package com.Bank.Dao;

import com.Bank.Dto.BankDto;
import org.apache.log4j.Logger;

import static org.junit.Assert.*;

public class BankDaoImplTest {
    static final Logger log=Logger.getLogger(BankDaoImpl.class);

    BankDto dt= new BankDto();
    BankDao bankDao= new BankDaoImpl() ;
    @org.junit.Test
    public void createAccountInDao()
    {

        dt.setName("manisha");
        dt.setPassword("6852");
        dt.setBankName("SBii");
        dt.setAmount(400);
        dt.setEmailId("manisha@gmail.com");
        dt.setAddress("lingampally");

       int testResult= bankDao.createAccountInDao(dt);

        assertEquals(1,testResult);

    }

    @org.junit.Test
    public void retriveCustomerDetails()
    {
     Object o= bankDao.retriveCustomerDetails("4562");

            // assertEquals(,o);
    }

    @org.junit.Test
    public void deleteCustomerFromBankDao()
    {
   int deleteresult=bankDao.deleteCustomerFromBankDao("shfg");
    assertEquals(1,deleteresult);
    }

    @org.junit.Test
    public void amountAddDao()
    {
        dt.setPassword("4795");
        dt.setAmount(5000);
        int addResult=bankDao.amountAddDao(dt);
      assertEquals(1,addResult);
    }

    @org.junit.Test
    public void receiveMoneyFromAccountDao()
    {
     dt.setName("navi");
     dt.setPassword("4795");
     dt.setAmount(290);
     double recieveResult=bankDao.receiveMoneyFromAccountDao(dt);

     log.info(recieveResult+"in test");
     assertEquals(-1,recieveResult);
    }
}