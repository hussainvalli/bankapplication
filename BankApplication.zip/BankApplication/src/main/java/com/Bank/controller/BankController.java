package com.Bank.controller;

import com.Bank.Bo.BankBo;
import com.Bank.service.BankService;
import com.Bank.service.BankServiceImpl;
import com.google.gson.Gson;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;


public class BankController extends HttpServlet
{
   /*This logging allows you to report and persist error and warning
   messages as well as info messages
   */
   static final Logger log=Logger.getLogger(BankController.class);

    int createresult;
    int deleteResult;
    //Creating the Object for implementation class of BankService interface

    public BankService bankService= new BankServiceImpl();

    //This dopost is used to create the account for the user
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException
    {
        //By using this method you are just specifying what kind of data you are going to send to the client.
        resp.setContentType("text/html");

        //enables you to write formatted data to an underlying Writer
        PrintWriter out=resp.getWriter();

        //Create the object for BankBo model object and set the values to that and send that object to service Class
        BankBo bo=new BankBo();
        bo.setName(req.getParameter("name"));
        bo.setBankName(req.getParameter("BankName"));
        bo.setPassword(req.getParameter("password"));
        bo.setAddress(req.getParameter("address"));
        bo.setEmailId(req.getParameter("emailId"));
        bo.setAmount(Double.parseDouble(req.getParameter("amount")));

        /*Service Class(i.e BankServiceImpl) method  returns the result of creation.
         by passing model Object
        */
        createresult=bankService.CreatingAccountinService(bo);

       // out.println("resultin:"+createresult);
        Gson gson=new Gson();
        String json=gson.toJson(createresult);
        out.println(json);

    }

    /*this doGet is used to retrive the user details by passing the password of the user
    * */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();

        //receiving the password from the request object
        String password =req.getParameter("password");

        /*by passing the input as password to the retriveCustomerDataFromBankservice()
        it will returns the customer object
        * */
        BankBo CustomerDetails= bankService.retriveCustomerDataFromBankservice(password);

            //Gson object generates JSON from Java objects.
            Gson gson=new Gson();
            String json=gson.toJson(CustomerDetails);
            out.println(json);
    }

    /*this doDelete method is used to delete the customer account by passing the address of customer.
    * */
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();
        BankBo bo=new BankBo();
        /*
        receiving the address from the request object
        and send it to deleteCustomerFromBank() to delete the customer details
        * */
        String address =bo.setAddress(req.getParameter("address"));
        deleteResult=bankService.deleteCustomerFromBank(address);

        Gson gson=new Gson();
        String json=gson.toJson(deleteResult);
        out.println(json);
    }
    /*
    * this doPost is used for credit and debit the customerBalance
    * */
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {

        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();

        int parametercount=0;
        BankBo bo=new BankBo();

        /*to know the no.of request parameters sent by customer.
        * based on the parameter count it perform either credit or debit operations.
        * */
        Enumeration e= req.getParameterNames();
        while(e.hasMoreElements())
        {
            parametercount++;
            Object o=e.nextElement();
        }

        //if user sends two parameters then it is creditoperation else it is debitoperation
        if (parametercount==2) {
            //credit is done by passing password and amount how much user want to credit.
            String password = req.getParameter("password");
            bo.setPassword(password);
            //converting string type to required double type
            double amt = Double.parseDouble(req.getParameter("amount"));
            bo.setAmount(amt);

            /*send this parameters to addMoneyToCustomerAccount() method by binding the BankBo object
             it will return the creditresult
            * */
            int CreditResult = bankService.addMoneyToCustomerAccount(bo);
            Gson gson=new Gson();
            String json=gson.toJson(CreditResult);
            out.println(json);

        }
        else
        {
            String rname = req.getParameter("name");
            bo.setName(rname);
            String pass1 = req.getParameter("password");
            bo.setPassword(pass1);
            double amt1 = Double.parseDouble(req.getParameter("amount"));
            bo.setAmount(amt1);
            /*receive the money by passing name and password to receiveMoneyFromAccount()method
            as a BankBo object .this method returns the amount
            * */

            double response=bankService.receiveMoneyFromAccount(bo);

            //Gson object generates JSON from Java objects.
            Gson gson=new Gson();
            String json=gson.toJson(response);
            out.println(json);

        }

    }

}
