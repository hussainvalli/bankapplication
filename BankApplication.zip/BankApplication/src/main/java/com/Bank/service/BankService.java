package com.Bank.service;

import com.Bank.Bo.BankBo;
import com.Bank.Dto.BankDto;

import java.util.List;
//it is an interface. for these interface BankServiceImpl is the implementaionclass.
public interface BankService
{
    public int CreatingAccountinService(BankBo bo);

    public BankBo retriveCustomerDataFromBankservice(String BankName);

    public int deleteCustomerFromBank(String address);

    public int addMoneyToCustomerAccount(BankBo bo);

    public double receiveMoneyFromAccount(BankBo bo);
}
