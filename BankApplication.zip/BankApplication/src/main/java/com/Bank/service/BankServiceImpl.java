package com.Bank.service;

import com.Bank.Bo.BankBo;
import com.Bank.Dto.BankDto;
import com.Bank.Dao.BankDao;
import com.Bank.Dao.BankDaoImpl;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class BankServiceImpl implements BankService
{
    /*This logging allows you to report and persist error and warning
   messages as well as info messages
   */
    static final Logger log=Logger.getLogger(BankServiceImpl.class);
        BankBo bo=new BankBo();
        public BankDao bdao=new BankDaoImpl();
        //this method is used to create the account for user by receiving the BankBo object from controller
              public int CreatingAccountinService(BankBo bo)
              {
                  BankDto dto=new BankDto();
                  //converting BankBo object to BankDto Object and send this object to daolayer
                  //BankDto Object is used when ever we required to do businesslogic
                   dto.setName(bo.getName());
                   dto.setBankName(bo.getBankName());
                   dto.setAddress(bo.getAddress());
                   dto.setPassword(bo.getPassword());
                   dto.setEmailId(bo.getEmailId());
                   dto.setAmount(bo.getAmount());

                   //log.info(dto+"in service");
                   //pass BankDto object to createAccountForTheCustomer()method.

                   int createstatus=bdao.createAccountInDao(dto);
                   return createstatus;
              }
      //this method is used to retrive the customer details by passing customer password
   @Override
    public BankBo retriveCustomerDataFromBankservice(String password)
    {


        BankDto detailsFromDao=bdao.retriveCustomerDetails(password);


            BankBo bo=new BankBo();

            bo.setName(detailsFromDao.getName());
            bo.setBankName(detailsFromDao.getBankName());
            bo.setEmailId(detailsFromDao.getEmailId());
            bo.setAddress(detailsFromDao.getAddress());
            bo.setAmount(detailsFromDao.getAmount());

         return bo;
    }
    //it will delete customer informtion by passing address of the customer
    @Override
    public int deleteCustomerFromBank(String address)
    {
       int k= bdao.deleteCustomerFromBankDao(address);
       return k;
    }

    //it will add money to the customer account

    @Override
    public int addMoneyToCustomerAccount(BankBo bo)
    {

        BankDto dto=new BankDto();

        dto.setPassword(bo.getPassword());
        dto.setAmount(bo.getAmount());

        int Creditstatus=bdao.amountAddDao(dto);

        return Creditstatus;
    }

    //customer get the money from customerAccount by passing credentials
    @Override
    public double receiveMoneyFromAccount(BankBo bo)
    {

        BankDto dto=new BankDto();
       //name & password is the credentials for the customer
        dto.setName(bo.getName());
        dto.setPassword(bo.getPassword());
        dto.setAmount(bo.getAmount());

        //by passing the dto object(i.e name&password) it will return the amount

        double receivingstatus=bdao.receiveMoneyFromAccountDao(dto);

         //it will generete the messege in loggerfile
       //log.info(receivingstatus+" in service");

         return  receivingstatus;
    }
}
