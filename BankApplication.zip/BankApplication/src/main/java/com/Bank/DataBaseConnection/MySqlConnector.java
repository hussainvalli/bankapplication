package com.Bank.DataBaseConnection;

import java.sql.Connection;
import java.sql.DriverManager;

//this class is establishing connection with database
public class MySqlConnector
{
    Connection con=null;

//method which returns the connection Object
    public Connection getConnection()
    {
        try {
            //Loading the DriverClass
            Class.forName("com.mysql.jdbc.Driver");
            //Establishing connection with Database
            con= DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank","root","root_rocks123");

        }catch (Exception e)
        {
            e.printStackTrace();
        }
        return con;
    }
}
